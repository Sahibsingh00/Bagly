

export const allProducts = [
    {
        "id": 1386,
        "name": "modello test",
        "slug": "modello-test",
        "price": "0.50",
        "regular_price": "",
        "price_html": "<span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span>",
        "thumbnail": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/04\/CPO3920-300x300.jpeg",
        "variations": [
            {
                "attributes": {
                    "attribute_pa_color": "laminato-blue"
                },
                
                "display_price": 0.9,
                "price_html": "<del aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/del> <span class=\"screen-reader-text\">Il prezzo originale era: &euro;1.<\/span><ins aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/ins><span class=\"screen-reader-text\">Il prezzo attuale \u00e8: &euro;1.<\/span>",
                "variation_gallery_images": [
                    {
                        
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "archive_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226-324x324.jpeg",
                    }
                ]
            },
            {
                "attributes": {
                    "attribute_pa_color": "laminatoblue"
                },
                "display_price": 0.5,
                "price_html": "<del aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/del> <span class=\"screen-reader-text\">Il prezzo originale era: &euro;1.<\/span><ins aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/ins><span class=\"screen-reader-text\">Il prezzo attuale \u00e8: &euro;1.<\/span>",
                "variation_gallery_images": [
                    {
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6081.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6081.jpeg",
                        "archive_src": "https://admin.bagly.it/wp-content/uploads/2024/06/CPO6115-324x324.jpg",
                    }
                ]
            }
        ]
    },
    {
        "id": 1386,
        "name": "modello test",
        "slug": "modello-test",
        "price": "0.50",
        "regular_price": "",
        "price_html": "<span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span>",
        "thumbnail": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/04\/CPO3920-300x300.jpeg",
        "variations": [
            {
                "attributes": {
                    "attribute_pa_color": "laminato-blue"
                },
                
                "display_price": 0.9,
                "price_html": "<del aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/del> <span class=\"screen-reader-text\">Il prezzo originale era: &euro;1.<\/span><ins aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/ins><span class=\"screen-reader-text\">Il prezzo attuale \u00e8: &euro;1.<\/span>",
                "variation_gallery_images": [
                    {
                        
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "archive_src": "https://admin.bagly.it/wp-content/uploads/2024/06/CPO6115-324x324.jpg",
                    }
                ]
            }
        ]
    },
    {
        "id": 1386,
        "name": "modello test",
        "slug": "modello-test",
        "price": "0.50",
        "regular_price": "",
        "price_html": "<span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span>",
        "thumbnail": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/04\/CPO3920-300x300.jpeg",
        "variations": [
            {
                "attributes": {
                    "attribute_pa_color": "laminato-blue"
                },
                
                "display_price": 0.9,
                "price_html": "<del aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/del> <span class=\"screen-reader-text\">Il prezzo originale era: &euro;1.<\/span><ins aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/ins><span class=\"screen-reader-text\">Il prezzo attuale \u00e8: &euro;1.<\/span>",
                "variation_gallery_images": [
                    {
                        
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "archive_src": "https://admin.bagly.it/wp-content/uploads/2024/06/CPO4399-300x300.jpg",
                    }
                ]
            }
        ]
    },
    {
        "id": 1386,
        "name": "modello test",
        "slug": "modello-test",
        "price": "0.50",
        "regular_price": "",
        "price_html": "<span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span>",
        "thumbnail": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/04\/CPO3920-300x300.jpeg",
        "variations": [
            {
                "attributes": {
                    "attribute_pa_color": "laminato-blue"
                },
                
                "display_price": 0.9,
                "price_html": "<del aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/del> <span class=\"screen-reader-text\">Il prezzo originale era: &euro;1.<\/span><ins aria-hidden=\"true\"><span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">&euro;<\/span>1<\/bdi><\/span><\/ins><span class=\"screen-reader-text\">Il prezzo attuale \u00e8: &euro;1.<\/span>",
                "variation_gallery_images": [
                    {
                        
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO6226.jpeg",
                        "archive_src": "https://admin.bagly.it/wp-content/uploads/2024/06/CPO4399-300x300.jpg",
                    },
                    {
                        "url": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO5800.jpeg",
                        "gallery_thumbnail_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO5800.jpeg",
                        "archive_src": "https:\/\/admin.bagly.it\/wp-content\/uploads\/2024\/06\/CPO5800-324x324.jpeg",
                    }
                ]
            }
        ]
    },
    
  ];